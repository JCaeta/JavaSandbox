package com.JavaSandbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSandboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSandboxApplication.class, args);
	}

}
